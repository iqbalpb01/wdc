from flask import Flask, render_template, request, session, redirect, url_for
import csv

app = Flask(__name__)
#app.secret_key = "123456789" # Secret key for session
button_numbers = []
for x in range(37):
    button_numbers.append(x+1)
clicked_buttons = set()

links = []
# flask_wd\links.csv
with open('d:/python/flask_wd/links.csv', newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        links.append(row)

@app.route('/')
def index():
    return render_template('index.html', button_numbers=button_numbers, clicked_buttons=clicked_buttons)

@app.route('/click_button', methods=['POST'])
def click_button():
    button_number = int(request.form['button_number'])

    # If button is not clicked before, add it to clicked_buttons
    if button_number not in clicked_buttons:
        clicked_buttons.add(button_number)

    return redirect(url_for('button_page', button_number=button_number))

@app.route('/button_page/<int:button_number>')
def button_page(button_number):
    image_file = f"images/image{button_number}.png" # Assuming images are named as image1.jpg, image2.jpg etc. in a folder named "images"
    return render_template('button_page.html', button_number=button_number, image_file=image_file, links=links)

if __name__ == '__main__':
    app.run()

